#include <iostream>

using namespace std;

int main(){

    typedef int Itemtype;

    string str1[1];
    str1[0] = NULL;
    if(str1[0] == NULL){
        cout << "T"<<endl;
    }
    return 0;
}
