#include <iostream>
#include <vector>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <cstdio.h>

using namespace std;


int main(){
    


}
