#include <iostream>
#include <string>

using namespace std;

int main(){

    int h;
    int m;

    scanf("%d:%d",&h,&m);

    cout << h << endl << m << endl;

    return 0;

}
